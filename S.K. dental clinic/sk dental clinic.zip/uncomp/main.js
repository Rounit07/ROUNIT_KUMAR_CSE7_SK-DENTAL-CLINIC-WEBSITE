(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').addClass('shadow-sm').css('top', '0px');
        } else {
            $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // // Date and time picker
    // $('.date').datetimepicker({
    //     format: 'L'
    // });
    // $('.time').datetimepicker({
    //     format: 'LT'
    // });


    // Header carousel
    $(".header-carousel").owlCarousel({
        autoplay: true,
        slideSpeed: 2000,
        animateOut: 'fadeOutLeft',
        items: 1,
        dots: true,
        loop: true,
        nav : false,
        // navText : [
        //     '<i class="bi bi-chevron-left"></i>',
        //     '<i class="bi bi-chevron-right"></i>'
        // ]
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1000,
        center: true,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            }
        }
    });

    
})(jQuery);

script src="js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('appointmentForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission

            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const mobile = document.getElementById('mobile').value;
            const problem = document.getElementById('problem').value;

            // Simple validation (you can expand this as needed)
            if (name && email && mobile && problem) {
                // Display confirmation message
                const confirmationMessage = `
                    <div class="alert alert-success">
                        Thank you, ${name}! Your appointment has been booked successfully. We will contact you at ${email} or ${mobile}.
                    </div>
                `;
                document.getElementById('confirmationMessage').innerHTML = confirmationMessage;
                document.getElementById('confirmationMessage').style.display = 'block';

                // Optionally, reset the form
                document.getElementById('appointmentForm').reset();
            } else {
                alert('Please fill in all fields.');
            }
        });
    </script>