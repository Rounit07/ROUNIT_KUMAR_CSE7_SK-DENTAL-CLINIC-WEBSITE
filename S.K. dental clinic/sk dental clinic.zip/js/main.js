(function(a) {
    "use strict";

    (function() {
        setTimeout(function() {
            if (0 < a("#spinner").length) {
                a("#spinner").removeClass("show");
            }
        }, 1);
    })();

    new WOW().init();

    a(window).scroll(function() {
        if (300 < a(this).scrollTop()) {
            a(".sticky-top").addClass("shadow-sm").css("top", "0px");
        } else {
            a(".sticky-top").removeClass("shadow-sm").css("top", "-100px");
        }
    });

    a(window).scroll(function() {
        if (300 < a(this).scrollTop()) {
            a(".back-to-top").fadeIn("slow");
        } else {
            a(".back-to-top").fadeOut("slow");
        }
    });

    a(".back-to-top").click(function() {
        a("html, body").animate({ scrollTop: 0 }, 1500, "easeInOutExpo");
        return false;
    });

    a("[data-toggle=\"counter-up\"]").counterUp({
        delay: 10,
        time: 2000
    });

    a(".header-carousel").owlCarousel({
        autoplay: true,
        slideSpeed: 2000,
        animateOut: "fadeOutLeft",
        items: 1,
        dots: true,
        loop: true,
        nav: false
    });

    a(".testimonial-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1000,
        center: true,
        dots: false,
        loop: true,
        nav: false,
        navText: [
            "<i class=\"bi bi-arrow-left\"></i>",
            "<i class=\"bi bi-arrow-right\"></i>"
        ],
        responsive: {
            0: { items: 1 },
            768: { items: 2 }
        }
    });
})(jQuery);