document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form submission

        const name = document.querySelector('input[placeholder="Your Name"]').value.trim();
        const email = document.querySelector('input[placeholder="Your Email"]').value.trim();
        const mobile = document.querySelector('input[placeholder="Your Mobile"]').value.trim();
        const password = document.querySelector('input[placeholder="Password"]').value.trim();

        if (!name || !email || !mobile || !password) {
            alert("All fields are required!");
            return;
        }

        // Simple email validation
        if (!/^\S+@\S+\.\S+$/.test(email)) {
            alert("Enter a valid email address!");
            return;
        }

        // Mobile number validation (10-digit number)
        if (!/^\d{10}$/.test(mobile)) {
            alert("Enter a valid 10-digit mobile number!");
            return;
        }

        // Password length validation
        if (password.length < 6) {
            alert("Password must be at least 6 characters!");
            return;
        }

        alert("Registration successful!");
        form.reset();
    });
});
